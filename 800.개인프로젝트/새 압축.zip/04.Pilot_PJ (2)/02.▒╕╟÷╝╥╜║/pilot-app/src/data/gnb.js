// GNB 페이지별 메뉴 데이터 - gnb.js
export const gnbData = {
    "main":["MEN","WOMEN","STYLE"],
    "men":[
      "NEW MEN'S ARRIVAL",
      "WINDBREAKER",
      "BEACH STYLE",
      "SPORT STYLE",
    ],
    "women":[  
      "NEW WOMEN'S ARRIVAL",
      "SPORTY FASHION",
      "FREE STYLE",
      "COMFORTABLE STYLE",
    ],
    "style":[
      "SPECIAL SUMMER STYLE",
      "GOLF LIFE",
      "CAMPING STYLE",
      "SPORT STYLE",
    ],
}; //////////////// gnbData ////////////////