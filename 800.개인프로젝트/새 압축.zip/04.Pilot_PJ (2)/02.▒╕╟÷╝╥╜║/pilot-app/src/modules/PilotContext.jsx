// Pilot PJ 컨텍스트 API 설정

import { createContext } from "react";

export const pCon = createContext();